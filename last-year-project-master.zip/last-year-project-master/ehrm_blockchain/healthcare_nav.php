<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
</head>
<body>
<nav>
            <ul>
                <li><a href="mine_block.php"><i class="fas fa-cube icon"></i>Mine Block</a></li>
                <li><a href="new_transaction_form.php"><i class="fas fa-plus icon"></i>New Transaction</a></li>
                <li><a href="view_block.php"><i class="fas fa-list icon"></i>View Blockchain</a></li>
				<li><a href="viewDecrypt.php"><i class="fas fa-list icon"></i>View Decrypted Chain</a></li>
				<li><a href="data_security.php"><i class="fas fa-lock icon"></i>View DataSecurity</a></li>
				<li><a href="../dashboard.php"><i class="fa fa-tachometer"></i>Dashboard</a></li>
            </ul>
            
        </nav>
</body>
</html>