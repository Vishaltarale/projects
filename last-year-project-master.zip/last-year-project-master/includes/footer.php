<script src="js/jquery.min.js"></script>
<script src="js/main.js"></script>
</body>
</html>